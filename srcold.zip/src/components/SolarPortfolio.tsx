import React, { useState } from "react";
import {
  Sun,
  Zap,
  Shield,
  Leaf,
  Phone,
  Mail,
  MapPin,
  Menu,
  X,
  Star,
  Users,
  Award,
  CheckCircle,
} from "lucide-react";

const SolarPortfolio = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = () => {
    if (formData.name && formData.email && formData.phone && formData.message) {
      alert("Thank you for your message! We will contact you soon.");
      setFormData({ name: "", email: "", phone: "", message: "" });
    } else {
      alert("Please fill in all fields.");
    }
  };

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
    setIsMenuOpen(false);
  };

  const services = [
    {
      icon: <Sun className="w-12 h-12 text-yellow-500" />,
      title: "Residential Solar",
      description:
        "Complete rooftop solar solutions for homes with maximum efficiency and cost savings.",
    },
    {
      icon: <Zap className="w-12 h-12 text-blue-500" />,
      title: "Commercial Solar",
      description:
        "Large-scale solar installations for businesses and industrial facilities.",
    },
    {
      icon: <Shield className="w-12 h-12 text-green-500" />,
      title: "Maintenance & Support",
      description:
        "24/7 monitoring and maintenance services to ensure optimal performance.",
    },
    {
      icon: <Leaf className="w-12 h-12 text-emerald-500" />,
      title: "Green Energy Consulting",
      description:
        "Expert consultation on renewable energy solutions and government incentives.",
    },
  ];

  const projects = [
    {
      title: "Modern Villa Installation",
      capacity: "25 kW",
      savings: "₹2.5L/year",
      image:
        "https://images.unsplash.com/photo-1509391366360-2e959784a276?w=500&h=300&fit=crop",
    },
    {
      title: "Commercial Complex",
      capacity: "100 kW",
      savings: "₹8L/year",
      image:
        "https://images.unsplash.com/photo-1497440001374-f26997328c1b?w=500&h=300&fit=crop",
    },
    {
      title: "Industrial Plant",
      capacity: "500 kW",
      savings: "₹35L/year",
      image:
        "https://images.unsplash.com/photo-1466611653911-95081537e5b7?w=500&h=300&fit=crop",
    },
    {
      title: "Residential Complex",
      capacity: "75 kW",
      savings: "₹5L/year",
      image:
        "https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?w=500&h=300&fit=crop",
    },
    {
      title: "Shopping Mall",
      capacity: "200 kW",
      savings: "₹15L/year",
      image:
        "https://images.unsplash.com/photo-1497435334941-8c899ee9e8e9?w=500&h=300&fit=crop",
    },
    {
      title: "Educational Institute",
      capacity: "150 kW",
      savings: "₹12L/year",
      image:
        "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=500&h=300&fit=crop",
    },
  ];

  const stats = [
    {
      number: "500+",
      label: "Projects Completed",
      icon: <Award className="w-8 h-8 text-yellow-500" />,
    },
    {
      number: "50MW+",
      label: "Total Capacity",
      icon: <Zap className="w-8 h-8 text-blue-500" />,
    },
    {
      number: "1000+",
      label: "Happy Customers",
      icon: <Users className="w-8 h-8 text-green-500" />,
    },
    {
      number: "5",
      label: "Years Experience",
      icon: <Star className="w-8 h-8 text-purple-500" />,
    },
  ];

  const NavLink = ({ section, children }) => (
    <button
      onClick={() => scrollToSection(section)}
      className="px-4 py-2 rounded-full text-gray-700 hover:text-yellow-600 hover:bg-yellow-50 transition-all duration-300"
    >
      {children}
    </button>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-yellow-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md shadow-lg sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-12 h-12 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
                <Sun className="w-8 h-8 text-white" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-yellow-600 to-orange-600 bg-clip-text text-transparent">
                SolarTech Pro
              </span>
            </div>

            <nav className="hidden md:flex space-x-2">
              <NavLink section="home">Home</NavLink>
              <NavLink section="about">About</NavLink>
              <NavLink section="services">Services</NavLink>
              <NavLink section="portfolio">Portfolio</NavLink>
              <NavLink section="contact">Contact</NavLink>
            </nav>

            <button
              className="md:hidden p-2 rounded-lg hover:bg-gray-100"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>

          {/* Mobile Menu */}
          {isMenuOpen && (
            <div className="md:hidden mt-4 p-4 bg-white rounded-lg shadow-lg">
              <div className="flex flex-col space-y-2">
                <NavLink section="home">Home</NavLink>
                <NavLink section="about">About</NavLink>
                <NavLink section="services">Services</NavLink>
                <NavLink section="portfolio">Portfolio</NavLink>
                <NavLink section="contact">Contact</NavLink>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section
        id="home"
        className="min-h-screen flex items-center py-20 relative overflow-hidden"
      >
        {/* Background Elements */}
        <div className="absolute inset-0">
          <div className="absolute top-20 right-20 w-64 h-64 bg-yellow-200 rounded-full opacity-20 animate-pulse"></div>
          <div className="absolute bottom-20 left-20 w-48 h-48 bg-blue-200 rounded-full opacity-20 animate-pulse delay-1000"></div>
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-6xl lg:text-7xl font-bold mb-6 bg-gradient-to-r from-yellow-600 via-orange-500 to-red-500 bg-clip-text text-transparent leading-tight">
                Power Your Future
              </h1>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                Leading solar panel installation company providing clean,
                renewable energy solutions for homes and businesses across
                India. Join the solar revolution today!
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mb-12">
                <button
                  onClick={() => scrollToSection("contact")}
                  className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-8 py-4 rounded-full font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
                >
                  Get Free Quote
                </button>
                <button
                  onClick={() => scrollToSection("portfolio")}
                  className="border-2 border-yellow-400 text-yellow-600 px-8 py-4 rounded-full font-semibold hover:bg-yellow-50 transition-all duration-300"
                >
                  View Projects
                </button>
              </div>

              {/* Stats Section */}
              <div className="grid grid-cols-2 gap-6">
                {stats.map((stat, index) => (
                  <div
                    key={index}
                    className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 text-center shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
                  >
                    <div className="flex justify-center mb-4">{stat.icon}</div>
                    <div className="text-3xl font-bold text-gray-800 mb-2">
                      {stat.number}
                    </div>
                    <div className="text-gray-600">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative">
              <div className="relative rounded-3xl overflow-hidden shadow-2xl">
                <img
                  src="https://images.unsplash.com/photo-1509391366360-2e959784a276?w=800&h=600&fit=crop"
                  alt="Solar panels on roof"
                  className="w-full h-[500px] object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent flex items-end">
                  <div className="p-8 text-white">
                    <h3 className="text-2xl font-bold mb-2">
                      Clean Energy for Tomorrow
                    </h3>
                    <p className="text-lg opacity-90">
                      Join thousands of satisfied customers
                    </p>
                  </div>
                </div>
              </div>

              {/* Floating Card */}
              <div className="absolute -bottom-6 -right-6 bg-gradient-to-r from-green-400 to-blue-500 text-white p-6 rounded-2xl shadow-lg">
                <div className="text-2xl font-bold">₹50,000+</div>
                <div className="text-sm">Monthly Savings</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-5xl font-bold text-center mb-12 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              About SolarTech Pro
            </h2>

            <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
              <div>
                <h3 className="text-3xl font-bold mb-6 text-gray-800">
                  Leading Solar Innovation
                </h3>
                <p className="text-lg text-gray-600 mb-6">
                  With over 5 years of experience in the solar industry,
                  SolarTech Pro has been at the forefront of renewable energy
                  solutions in India. We specialize in designing, installing,
                  and maintaining solar panel systems that maximize energy
                  efficiency and cost savings.
                </p>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="w-6 h-6 text-green-500" />
                    <span className="text-gray-700">
                      Certified solar installation experts
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="w-6 h-6 text-green-500" />
                    <span className="text-gray-700">
                      Premium quality panels and equipment
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="w-6 h-6 text-green-500" />
                    <span className="text-gray-700">
                      25-year performance warranty
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="w-6 h-6 text-green-500" />
                    <span className="text-gray-700">
                      Complete end-to-end service
                    </span>
                  </div>
                </div>
              </div>
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?w=600&h=400&fit=crop"
                  alt="Solar team"
                  className="rounded-2xl shadow-2xl"
                />
                <div className="absolute -bottom-6 -right-6 bg-gradient-to-r from-yellow-400 to-orange-500 text-white p-6 rounded-2xl shadow-lg">
                  <div className="text-2xl font-bold">ISO 9001</div>
                  <div className="text-sm">Certified Company</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section
        id="services"
        className="py-20 bg-gradient-to-br from-gray-50 to-blue-50"
      >
        <div className="container mx-auto px-4">
          <h2 className="text-5xl font-bold text-center mb-16 bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
            Our Services
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 group"
              >
                <div className="flex justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                  {service.icon}
                </div>
                <h3 className="text-xl font-bold mb-4 text-center text-gray-800">
                  {service.title}
                </h3>
                <p className="text-gray-600 text-center">
                  {service.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-5xl font-bold text-center mb-16 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            Our Projects
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2"
              >
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-3 text-gray-800">
                    {project.title}
                  </h3>
                  <div className="flex justify-between items-center mb-4">
                    <span className="bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-sm font-semibold">
                      {project.capacity}
                    </span>
                    <span className="bg-green-100 text-green-600 px-3 py-1 rounded-full text-sm font-semibold">
                      {project.savings}
                    </span>
                  </div>
                  <button className="w-full bg-gradient-to-r from-yellow-400 to-orange-500 text-white py-2 rounded-full font-semibold hover:shadow-lg transition-all duration-300">
                    View Details
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section
        id="contact"
        className="py-20 bg-gradient-to-br from-gray-50 to-blue-50"
      >
        <div className="container mx-auto px-4">
          <h2 className="text-5xl font-bold text-center mb-16 bg-gradient-to-r from-red-600 to-pink-600 bg-clip-text text-transparent">
            Contact Us
          </h2>
          <div className="max-w-6xl mx-auto">
            <div className="grid lg:grid-cols-2 gap-12">
              {/* Contact Form */}
              <div className="bg-white rounded-2xl p-8 shadow-lg">
                <h3 className="text-2xl font-bold mb-6 text-gray-800">
                  Get Free Quote
                </h3>
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Full Name
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-yellow-400 focus:outline-none transition-colors"
                      placeholder="Enter your name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Email Address
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-yellow-400 focus:outline-none transition-colors"
                      placeholder="Enter your email"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-yellow-400 focus:outline-none transition-colors"
                      placeholder="Enter your phone number"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Message
                    </label>
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleInputChange}
                      rows={4}
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-yellow-400 focus:outline-none transition-colors"
                      placeholder="Tell us about your project requirements"
                    />
                  </div>
                  <button
                    onClick={handleSubmit}
                    className="w-full bg-gradient-to-r from-yellow-400 to-orange-500 text-white py-4 rounded-lg font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
                  >
                    Send Message
                  </button>
                </div>
              </div>

              {/* Contact Info */}
              <div className="space-y-8">
                <div className="bg-gradient-to-r from-yellow-400 to-orange-500 rounded-2xl p-8 text-white">
                  <h3 className="text-2xl font-bold mb-6">Get In Touch</h3>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-4">
                      <Phone className="w-6 h-6" />
                      <div>
                        <div className="font-semibold">Phone</div>
                        <div className="opacity-90">+91 98765 43210</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <Mail className="w-6 h-6" />
                      <div>
                        <div className="font-semibold">Email</div>
                        <div className="opacity-90">info@solartechpro.com</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <MapPin className="w-6 h-6" />
                      <div>
                        <div className="font-semibold">Address</div>
                        <div className="opacity-90">
                          123 Solar Street, Jaipur, Rajasthan 302001
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-2xl p-8 shadow-lg">
                  <h3 className="text-xl font-bold mb-4 text-gray-800">
                    Why Choose Us?
                  </h3>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                      <span className="text-gray-700">
                        Free site inspection & consultation
                      </span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                      <span className="text-gray-700">
                        Quick installation in 1-2 days
                      </span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                      <span className="text-gray-700">
                        Government subsidy assistance
                      </span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                      <span className="text-gray-700">
                        24/7 customer support
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
                <Sun className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold">SolarTech Pro</span>
            </div>
            <p className="text-gray-400 mb-6">
              Leading the solar revolution with innovative renewable energy
              solutions.
            </p>
            <div className="flex justify-center space-x-6 mb-6">
              <Phone className="w-6 h-6 text-gray-400 hover:text-yellow-400 cursor-pointer transition-colors" />
              <Mail className="w-6 h-6 text-gray-400 hover:text-yellow-400 cursor-pointer transition-colors" />
              <MapPin className="w-6 h-6 text-gray-400 hover:text-yellow-400 cursor-pointer transition-colors" />
            </div>
            <div className="border-t border-gray-800 pt-6">
              <p className="text-gray-400">
                &copy; 2024 SolarTech Pro. All rights reserved.
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default SolarPortfolio;
