import React from 'react';
import SolarPortfolio from './components/SolarPortfolio';

function App() {
  return <SolarPortfolio />;
}

export default App;
